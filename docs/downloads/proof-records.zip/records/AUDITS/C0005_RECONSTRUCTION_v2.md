# C0005 independent reconstruction — v2

Created: 2026-09-05 UTC.

Status: **self-audited independent argument; not compared or promoted**.

This reconstructs the exact auxiliary contract in CONTRACT_v2.md. It makes no assertion about an unseen candidate proof, and does not prove the convergence statement in STATEMENT.md. The only mathematical text read was the three frozen inputs listed in the companion exposure record. No campaign dependency, external source, mathematical program, simulation, or subagent was used.

All constants denoted \(C_n\) or \(C_{n,p}\) below are finite and depend only on their indicated indices. They can be enlarged finitely many times to make the contract's simultaneous assertions hold. All estimates are uniform over positions, partitions, label subsets, and functions with the stated Lipschitz constant.

## 1. Basic chain facts and absorption

Fix \(n\ge2\). Both generators have uniformly bounded total jump rates: \(R\) has rate \(2n\), and \(I\) has rate at most \(n(n-1)\). Thus their chains can be constructed by independent Poisson proposals, with rejected proposals allowed. This also gives nonexplosion, the strong Markov property, and the stopped generator identity for bounded functions. The martingale and stopping identities below also apply to functions with bounded increments, by stopping after a bounded number of proposals and then using the displayed moment bounds.

An \(I\)-jump never creates an occupied site. Consequently a label remains in its original connected component of occupied sites. Such a component contains at most \(n\) consecutive integers, so every label moves at most \(n-1\) sites during an \(I\)-trajectory.

Let
\[
V(z)=\sum_x\eta_x(z)^2.
\]
For an unordered adjacent pair with occupancies \(a,b>0\), the two directed contributions to \(IV\) sum to \(4ab\). Hence
\[
IV=4\sum_x\eta_x\eta_{x+1}\ge4\mathbf1_{E_n\setminus S_n}.
\]
Since \(n\le V\le n^2\), the stopped generator identity gives
\[
4\mathbb E_z(t\wedge\tau)
 \le n^2-V(z)\le n(n-1).
\]
Letting \(t\) increase proves almost-sure absorption and
\[
\sup_z\mathbb E_z\tau\le c_n=\frac{n(n-1)}4.
\]
The defining expectation immediately gives \(\|U\|\le c_n\) and \(\|P\|\le1\).

We will repeatedly use the following elementary two-site calculation. If \(m\) labels occupy two adjacent sites and \(k\) are at the right site, the right-site population has upward and downward rates both equal to \(k(m-k)\). It is a bounded martingale absorbed at \(0,m\); its probability of absorption at \(m\) is \(k/m\).

## 2. Exact local structure of \(Q\)

From a state in \(S_n\), make one \(R\)-proposal and then run \(I\) to absorption. This gives a conservative proposal construction of \(Q\), of rate \(2n\). Self-returns may be discarded, so its off-diagonal rate is at most \(2n\).

The initiating step can create an \(I\)-component only on three consecutive sites: the old site, the newly occupied neighbor, and possibly an old occupied site two steps from the old site. All other components are singleton occupied sites. Thus every resulting label displacement is at most two.

Here are more precise consequences, including their probabilities.

* If a stack of \(m\) labels has no occupied site two steps away in a chosen direction, an initiating step in that direction leaves a two-site component, or simply moves a singleton. The two-site calculation shows that the entire stack translates one step in that direction at total \(Q\)-rate \(m(1/m)=1\).
* Suppose two stacks occupy \(x,x+2\), with total population \(m\). There are \(m\) initiating proposals into \(x+1\). During the ensuing \(I\)-evolution, the middle population \(k\) has equal upward and downward rates \(k(m-k)\), regardless of the distribution between the two endpoints. The first entrance in \(S_n\) occurs when this population reaches \(0\) or \(m\). Therefore the event that both stacks merge at \(x+1\) has total \(Q\)-rate exactly one.
* In the latter evolution, if the middle site becomes empty, only the two original endpoints can remain occupied. Otherwise all \(m\) labels occupy the middle site. A surviving endpoint can lose labels, including all its labels, but no additional occupied endpoint is produced.

It follows that \(K\) never increases. Choosing any one distance-two pair in a near configuration and using its rate-one middle merger gives
\[
QK\le-\mathbf1_{C_n^{\mathrm{near}}}.
\]
The stopped generator identity for bounded \(K\), followed by monotone convergence, yields
\[
\sup_{z\in S_n}\mathbb E_z A\le n-1,
\qquad
A=\int_0^\infty\mathbf1_{C_n^{\mathrm{near}}}(Y_s)\,ds.
\]
Tonelli's theorem and the strong Markov property imply
\[
\begin{aligned}
\mathbb E_z A^2
 &=2\mathbb E_z\int_0^\infty
 \mathbf1_{C_n^{\mathrm{near}}}(Y_s)
 \left(\int_s^\infty\mathbf1_{C_n^{\mathrm{near}}}(Y_u)\,du\right)ds\\
 &\le2(n-1)\mathbb E_z A
 \le2(n-1)^2.
\end{aligned}
\]

Outside the near set, \(Q\) moves each whole stack one step in either direction, each at rate one. These steps preserve a coordinate-order chamber, including its equality faces. For a chamber-affine \(f\), the two directional increments of each stack cancel. Hence
\[
Qf=0\quad\hbox{outside }C_n^{\mathrm{near}},
\qquad
|Qf|\le4n^2D\,\mathbf1_{C_n^{\mathrm{near}}}.
\tag{2.1}
\]
The bound uses rate at most \(2n\) and total coordinate displacement at most \(2n\).

For each coordinate, write
\[
Y_i(t)-z_i=M_i(t)+\int_0^t Qf_i(Y_s)\,ds.
\]
The martingale has predictable quadratic-variation rate at most \(8n\). The \(L^2\) maximal martingale inequality gives
\[
\mathbb E_z\sup_{s\le t}|M_i(s)|^2\le32nt.
\]
By (2.1), the absolute drift integral is bounded by \(4n^2A\). Summing over the finitely many coordinates, and using the second-moment bound for \(A\), proves
\[
\mathbb E_z\sup_{s\le t}\max_i|Y_i(s)-z_i|^2\le C_n(t+1).
\tag{2.2}
\]
The maximal inequality used here follows from the usual stopped square-martingale identity and the inequality
\(\mathbb E\sup_{s\le t}|M_s|^2\le4\mathbb E|M_t|^2\).

## 3. Canonical corrections and their global bounds

By (2.1) and the occupation bound,
\[
\mathbb E_z\int_0^\infty |Qf(Y_s)|\,ds
 \le4n^2(n-1)D=a_nD.
\]
Thus the potential in the contract is absolutely integrable and
\(\|\psi_f\|_\infty\le a_nD\).

The Markov property gives, for every \(t\ge0\),
\[
\psi_f(z)=
 \mathbb E_z\int_0^t Qf(Y_s)\,ds+\mathbb E_z\psi_f(Y_t).
\]
The bounded generator \(Q\), acting on bounded functions, permits differentiation at \(t=0\). Consequently
\[
Q\psi_f=-Qf,\qquad QH_f=0.
\tag{3.1}
\]
Linearity follows directly from the integrable defining potential.

Coordinate permutations and common integer translations commute with \(R,I,P,Q\) and preserve the near set. Changing variables in the defining potential proves
\[
\psi_{f\circ g}=\psi_f\circ g,\qquad H_{f\circ g}=H_f\circ g.
\]
An additive constant has zero correction.

From a full stack the \(Q\)-chain remains a full stack and translates at rate one in each direction. The restriction of \(f\) to the full diagonal is affine; therefore its \(Qf\) is zero throughout this class and its correction is zero there.

Write \(s(z)=\sum_i z_i\). Direct pairing of the two directions between adjacent occupied sites gives \(Is=0\), and \(Rs=0\). Since pure-\(I\) absorption stays in finitely many sites, optional stopping gives \(Ps=s\). Thus, for \(f=b+as\),
\[
Qf=0,\qquad \psi_f=0,\qquad RPf=0,\qquad BH_f=0.
\tag{3.2}
\]

The displacement bound for \(I\)-absorption gives, on all \(E_n\),
\[
|PH_f-f|\le \bigl(n(n-1)+a_n\bigr)D.
\tag{3.3}
\]
Since \(|Rf|\le2nD\), and \(\|Rh\|_\infty\le4n\|h\|_\infty\) for bounded \(h\),
\[
\|RPH_f\|_\infty\le C_nD.
\tag{3.4}
\]
The potential is zero on \(S_n\), so
\[
\|BH_f\|_\infty
 \le2n c_n\|RPH_f\|_\infty\le C_nD.
\tag{3.5}
\]
Equations (3.1)--(3.5) prove all conclusions in item 2.

## 4. Perturbed excursions, displacement, and potentials

Fix \(0<d\le d_n\), and put \(q=2nc_nd\le1/4\). Construct \(I+dR\) by running pure \(I\) between independent alarms of rate \(2nd\), each alarm choosing an \(R\)-proposal uniformly.

From any current state outside \(S_n\), the probability that an alarm precedes pure-\(I\) absorption is
\[
\mathbb E(1-e^{-2nd\tau})\le2nd\,\mathbb E\tau\le q.
\]
Restart this argument after each alarm, unless the alarm itself has entered \(S_n\). It proves, for the number \(J\) of alarms up to and including an alarm that causes entrance,
\[
\mathbb P(J\ge j)\le q^j,\qquad j\in\mathbb N_0.
\tag{4.1}
\]
This holds for every starting tuple. If that tuple is already in \(S_n\), \(J=\tau_d=0\).

Each pure-\(I\) segment, stopped also at its alarm, has expected duration at most \(c_n\). The expected number of segments is at most \((1-q)^{-1}\). Hence absorption is almost sure and
\[
\sup_x\mathbb E_x\tau_d\le\frac{c_n}{1-q}\le2c_n.
\tag{4.2}
\]
The strong Markov property and Markov's inequality at times \(4c_n,8c_n,\ldots\) give
\[
\sup_x\mathbb P_x(\tau_d>4c_n k)\le2^{-k}.
\]
Integrating this tail proves \(\sup_x\mathbb E_x\tau_d^p\le C_{n,p}\) for every real \(p\ge1\).

For an excursion initiated from \(z\in S_n\), initially there are at most \(n\) distinct visited sites. Including the initiating step and the subsequent \(J\) independent steps, at most \(n+1+J\) sites are ever visited: an \(I\)-step enters an already occupied, hence already visited, site. Every label follows a nearest-neighbor path. The interval between its initial site and any later site is therefore contained in the visited set, and has at most \(n+1+J\) sites. Consequently
\[
\max_i\sup_{s\le\tau_d}|X_i(s)-z_i|\le n+J.
\tag{4.3}
\]
The same argument from an arbitrary starting tuple, without an initiating step, gives displacement at most \(n-1+J\).

Summing the geometric bound (4.1), with \(q\le1/4\), yields
\[
\mathbb E(1+J)^p\le C_{n,p},\qquad
\mathbb E[(1+J)^p\mathbf1_{\{J\ge1\}}]\le C_{n,p}d.
\tag{4.4}
\]
For example, the second expectation is bounded by
\(\sum_{j\ge1}(1+j)^p q^j\), which is at most a finite constant depending on \(n,p\) times \(d\).

Let \(I^0\) be the killed generator on the complement of \(S_n\). Its killed semigroup decays in supremum norm, by the uniform mean absorption estimate and its Markov-property iteration. Integrating the semigroup and differentiating its integral shows
\[
(-I^0)U=U(-I^0)=\operatorname{Id}.
\]
The same statement holds for \(U_d\) and \(-(I^0+dR^0)\). Also \(\|R^0\|\le4n\), so
\[
d\|UR^0\|\le4nc_nd\le\frac12.
\]
Inverting the factorization of the killed generator gives
\[
U_d=(\operatorname{Id}-dUR^0)^{-1}U.
\tag{4.5}
\]
The inverse is its norm-convergent Neumann series. In particular,
\[
\|U_d\|\le2c_n,\qquad
\|U_d-U\|\le 2d\,c_n(4n)c_n=8nc_n^2d.
\tag{4.6}
\]
The two resolvent identities, obtained by multiplying these inverses, include
\[
U_d-U=dU_dR^0U.
\tag{4.7}
\]

For bounded boundary data \(b\), stopped Dynkin's identity applied to \(Pb\), which is \(I\)-harmonic, gives
\[
P_db-Pb=dU_dRPb.
\tag{4.8}
\]
Both sides vanish on \(S_n\). Equations (4.7)--(4.8), followed by \(R\) and restriction to \(S_n\), prove exactly
\[
T_db=Qb+dBb+d^2(RU_dR^0URPb)|_{S_n}.
\tag{4.9}
\]

These identities also hold for \(b=H_f\). Indeed (3.3) gives at most linear growth for \(PH_f\), with uniformly bounded increments. The arbitrary-start version of (4.3)--(4.4) makes all its stopped absorption values uniformly integrable. Its generator outside \(S_n\) is \(dRPH_f\), bounded by (3.4). Thus stopped Dynkin's identity passes to absorption without a residual term, proving (4.8), and then (4.9), for \(H_f\). Alternatively all these limits can first be stopped after finitely many proposals; the expected number of proposals before absorption is finite because the total rate is bounded and (4.2) holds.

Using (3.1), (3.4), (4.6), and \(\|R^0\|\le4n\) in (4.9) gives
\[
\|T_dH_f-dBH_f\|_\infty\le C_nDd^2,\qquad
\|T_dH_f\|_\infty\le C_nDd.
\tag{4.10}
\]

For the chain with generator \(R+d^{-1}I\), on \(S_n\) the only proposals are the \(R\)-proposals, at rate \(2n\). Off \(S_n\), its absorption distribution equals that of \(I+dR\), by a constant change of time. Removing excursion durations therefore produces exactly the proposal kernel \(T_d=RP_d\). Almost-sure return proves conservativity; its off-diagonal rate is at most \(2n\).

Finally, (4.3) and the correction bound imply, for every initiating proposal,
\[
|H_f(X_{\tau_d})-H_f(z)|
 \le Dn(n+J)+2a_nD.
\]
The proposal representation of \(T_d\), together with (4.4), proves
\[
\sum_{y\ne z}T_d(z,y)|H_f(y)-H_f(z)|^p\le C_{n,p}D^p.
\tag{4.11}
\]
For \(d=0\), use the displacement bound of two for \(Q\). This proves items 5 and 6.

## 5. Covariance bounds uniform in \(d\)

Equation (4.11) with \(p=2\), followed by the inequality
\(|ab|\le(a^2+b^2)/2\), proves absolute convergence and the uniform bound for every covariance series.

Couple an \(I+dR\) excursion with a pure-\(I\) excursion until its first independent alarm. On the event that no such alarm occurs before the pure-\(I\) absorption, their endpoints agree. On the complementary event, \(J\ge1\) for the perturbed excursion. The pure endpoint has label displacement at most two; the perturbed endpoint satisfies (4.3). The correction is bounded. Therefore, for every initiating proposal and every \(i,j\), the expected absolute difference between the two products of coordinate-corrector increments is bounded by
\[
C_n\left(
 \mathbb P(J\ge1)+
 \mathbb E[(1+J)^2\mathbf1_{\{J\ge1\}}]\right)
 \le C_nd.
\]
Summing the \(2n\) proposals proves
\[
\sup_{z,i,j}|\Gamma_d^{ij}(z)-\Gamma_0^{ij}(z)|\le C_nd.
\tag{5.1}
\]

## 6. Two elementary estimates for local harmonic functions

### 6.1 Coalescence of a finite isolated group

This argument applies to the \(Q\)-chain with any number \(m\ge2\) of labels. Let
\[
W=\max_i Y_i-\min_i Y_i,\qquad
\sigma=\inf\{t:W(Y_t)=0\}.
\]
A full stack remains a full stack, so \(\sigma\) is its coalescence time.

When there are at least two occupied sites, the two extreme stacks each move outward at rate one. These are exactly the transitions that increase \(W\); each increases it by one. At either extreme, if the next occupied site is at distance at least three, inward translation has rate one and decreases \(W\) by one. If that distance is two, the rate-one middle merger from Section 2 decreases \(W\) by at least one. When there are just two occupied sites at distance two, the shared middle-merger event decreases \(W\) by two and is counted only once. With at least three sites the two extreme merger events are distinct. Other transitions cannot increase \(W\). We have therefore proved that, whenever \(W>0\),

* upward jumps have size one and total rate two;
* the sum of downward rates times their displacement sizes is at least two.

For \(s>0\), put \(\lambda=4(\cosh s-1)\). Since
\(e^{ks}-1\ge k(e^s-1)\) for each positive integer \(k\), these two facts imply
\[
Qe^{-sW}\ge\lambda e^{-sW}\quad\hbox{when }W>0.
\]
Thus \(e^{-\lambda(t\wedge\sigma)}e^{-sW(Y_{t\wedge\sigma})}\) is a bounded submartingale. Sending \(t\) to infinity gives
\[
\mathbb E_y e^{-\lambda\sigma}\ge e^{-sW(y)},
\tag{6.1}
\]
where the integrand is defined as zero if \(\sigma=\infty\). Letting \(s\) decrease to zero proves \(\sigma<\infty\) almost surely. Set \(\lambda=1/t\) in (6.1). Because \(s\le(2t)^{-1/2}\),
\[
\mathbb P_y(\sigma>t)
 \le\frac{1-\mathbb E_y e^{-\sigma/t}}{1-e^{-1}}
 \le C\,\frac{W(y)}{\sqrt t}.
\tag{6.2}
\]
This estimate is also valid for a singleton group, with a zero left side.

### 6.2 A bounded harmonic gradient estimate

Consider independent integer random walks, one per full group, each jumping at rate one in each direction. Let \(h\) be bounded by \(M\) and harmonic in a box of radius \(3R\), and assume its values are bounded by \(M\) also at the exit sites. At points in the concentric box of radius \(R\),
\[
|h(a+e_j)-h(a)|\le C_kM R^{-1/2},
\qquad R\ge16,
\tag{6.3}
\]
where there are \(k\) groups and both points are in that smaller box.

For completeness, couple the differing coordinates by running them independently until they meet, and then synchronously; couple the other coordinates synchronously throughout. Before meeting, the positive difference is a random walk with generator \(2\Delta\), started at one. Applying the exponential argument of (6.1), now with equality for \(2\Delta\), gives a meeting-time tail at most \(C/\sqrt t\). The square-martingale maximal inequality bounds the chance that either walk exits the larger box by time \(t\) by \(C_kt/R^2\). Stop the bounded harmonic functions at exit or at time \(t\). On paths that have coupled before time \(t\) and neither exited, their terminal values agree. Their difference in expectations is therefore at most
\[
2M\left(Ct^{-1/2}+C_kt/R^2\right).
\]
Taking \(t=R\) proves (6.3). Values within a fixed extra lattice margin can be included by slightly decreasing the stopping box; this does not change the estimate or its uniform constants.

## 7. Exact full-stack splitting identity

We establish the identity in every dimension \(m\ge2\); the one-label case is zero. Put the full stack at zero.

First note a consequence of chamber-affinity. If the gradient of \(f\) on one order chamber is \(a^\sigma\), continuity across a common chamber wall implies that gradients of adjacent chambers differ by a multiple of the difference of the two swapped coordinate vectors. All chamber affine constants equal \(f(0)\). In particular
\[
A=\sum_i a^\sigma_i
\]
is independent of the chamber, and
\[
f(x+c\mathbf1)=f(x)+Ac.
\tag{7.1}
\]
The correction has the same common-translation invariance without the additive term.

For a proper nonempty subset \(A_0\) of the labels, let \(z_{A_0}(r,s)\) put that subset at \(r\) and its complement at \(s>r\). To avoid confusing this subset with the scalar in (7.1), write the latter as \(a_{\mathrm{tot}}\) from now on. There are constants \(\ell_{A_0},r_{A_0}\), with sum \(a_{\mathrm{tot}}\), such that
\[
f(z_{A_0}(r,s))
 =f(0)+\ell_{A_0}r+r_{A_0}s.
\]
Also
\[
\beta_{A_0}=r_{A_0}-\ell_{A_0}
 =\partial_{v_{A_0,\{1,\ldots,m\}}}f(0).
\tag{7.2}
\]
Translation invariance makes \(\psi_f(z_{A_0}(r,s))\) a function only of \(s-r\). At gaps at least three, (3.1) and the exact stack-translation rates give its second-difference equation with zero right side. A bounded sequence with zero second differences for every integer gap at least three is constant for all gaps at least two. Denote this constant by \(\gamma_{A_0}\).

We next prove the reversibility relations needed for a finite boundary calculation. For \(d>0\), define
\[
\nu_d(z)=\prod_{x:\eta_x(z)>0}(d)_{\eta_x(z)},
\qquad
(d)_a=d(d+1)\cdots(d+a-1).
\]
For a move of a specified label from a site of population \(a\) to one of population \(b\), the weight ratio is
\[
\frac{\nu_d(z+\epsilon e_i)}{\nu_d(z)}
 =\frac{d+b}{d+a-1}.
\]
The forward and reverse \(I+dR\) rates of this specified label move are \(d+b\) and \(d+a-1\). Thus detailed balance holds.

Its trace on \(S_m\) is consequently reversible with respect to \(\nu_d|_{S_m}\). One can see this without a finiteness assumption on the state space: expand a trace transition into its initial jump, its killed Green kernel outside \(S_m\), and its final jump. Reversing each term uses detailed balance of the two jumps and symmetry of the killed Green kernel. The latter follows by reversing finite killed transition paths and then integrating time. All terms are nonnegative and their row sums are finite, so the interchange of sums is justified by monotone convergence. Constant time rescaling does not change this assertion.

For a full stack, the leading weight is \(d(m-1)!\). For two stacks with populations \(a,m-a\), it is \(d^2(a-1)!(m-a-1)!\). Apply the bounded-data expansion (4.9) to individual point indicators in detailed balance and let \(d\) decrease to zero. This proves two facts:
\[
\kappa_{A_0}Q(z_{A_0}(0,2),z_{A_1}(0,2))
 =
\kappa_{A_1}Q(z_{A_1}(0,2),z_{A_0}(0,2)),
\tag{7.3}
\]
and
\[
B(\mathbf0,u)=\kappa_{A_0}Q(u,\mathbf0)
\tag{7.4}
\]
when \(u\) is a two-stack state with left label subset \(A_0\). Here
\[
\kappa_{A_0}=\frac{(|A_0|-1)!(m-|A_0|-1)!}{(m-1)!}.
\]
For (7.4), \(Q(\mathbf0,u)=0\); the first nonzero trace order on that side is \(dB(\mathbf0,u)\).

There are only finitely many states in the row of \(B\) from \(\mathbf0\). To verify this directly from its definition, the first \(R\)-step and following \(I\)-evolution have support on two adjacent sites. A second \(R\)-step can enlarge that support only to three consecutive sites. Subsequent \(I\)-absorption yields either a full stack or two endpoint stacks at gap two. Thus the only two-stack outputs are
\[
z_{A_0}(-c,2-c),\qquad c=0,1,2.
\tag{7.5}
\]
The remaining outputs are full stacks. The row sums to zero because \(B1=0\). Reflection of all coordinates commutes with \(R,I,P,U,B\); it makes the full-stack-to-full-stack coefficients symmetric in the destination coordinate. Their contribution to \(BH_f(\mathbf0)\) vanishes, since \(H_f\) is affine on the full diagonal.

Put
\[
h_{A_0}=H_f(z_{A_0}(0,2)),\qquad
\phi(c)=f(c\mathbf1),\qquad
q_{A_0,c}=Q(z_{A_0}(0,2),c\mathbf1).
\]
At \(z_{A_0}(0,2)\), the two outward stack moves contribute
\(-\ell_{A_0}+r_{A_0}=\beta_{A_0}\) to \(QH_f\), because the correction is constant in the gap. All other nontrivial transitions either retain the two endpoints and change the left label subset, or merge to \(c\mathbf1\), \(c=0,1,2\). The harmonic equation is therefore
\[
0=\beta_{A_0}
 +\sum_{A_1\ne A_0}Q(z_{A_0}(0,2),z_{A_1}(0,2))
       (h_{A_1}-h_{A_0})
 +\sum_{c=0}^2q_{A_0,c}(\phi(c)-h_{A_0}).
\]
Multiply by \(\kappa_{A_0}\) and sum over all oriented proper nonempty subsets. Relation (7.3) cancels the middle sum in pairs, leaving
\[
\sum_{A_0}\kappa_{A_0}\sum_{c=0}^2
 q_{A_0,c}(h_{A_0}-\phi(c))
 =\sum_{A_0}\kappa_{A_0}\beta_{A_0}.
\tag{7.6}
\]
By translation invariance, (7.4)--(7.5) identify the left side of (7.6) with \(BH_f(\mathbf0)\): the increment of \(H_f\) from \(\mathbf0\) to \(z_{A_0}(-c,2-c)\) is \(h_{A_0}-\phi(c)\). Therefore
\[
BH_f(\mathbf0)=
 \sum_{\varnothing\ne A_0\subsetneq\{1,\ldots,m\}}
 \frac{(|A_0|-1)!(m-|A_0|-1)!}{(m-1)!}
 \partial_{v_{A_0,\{1,\ldots,m\}}}f(\mathbf0).
\tag{7.7}
\]
Common translation proves the exact identity at any full stack. Every oriented subset was included separately; no factor of two has been removed.

## 8. Separated-group localization

Fix the partition and sites in item 3, and write \(R=R_*\ge16\). Enumerate groups in increasing spatial order. Within the region
\[
|u_i-x_B|\le4R\quad(i\in B),
\tag{8.1}
\]
different groups cannot interleave or interact, because their centers differ by at least \(16R\).

There are chamber-linear functions \(f_B\) on the coordinates of each group, each vanishing at zero and each having Lipschitz constant at most \(D\), such that in (8.1)
\[
f(u)=f(z)+\sum_B f_B(u_B-x_B\mathbf1).
\tag{8.2}
\]
Here is a direct construction. On each internal order chamber of a group, use the coordinates of the gradient of \(f\) in a global chamber respecting the fixed group order. Changing an internal order in another group can be done by adjacent transpositions there. By the chamber-wall calculation preceding (7.1), such a transposition changes no gradient coordinate in the chosen group. Thus the definition is independent of other groups' internal orders. The same wall calculation ensures continuity within each group; the sum of its slopes is independent of its internal order. This proves (8.2). The original Lipschitz bound bounds every coordinate slope by \(D\), so it gives the claimed group Lipschitz bound.

Use the already constructed lower-dimensional corrections, with the explicit affine convention for singleton groups, and set on \(S_n\)
\[
F(u)=f(z)+\sum_B H^{(|B|)}_{f_B}(u_B-x_B\mathbf1).
\]
In the region (8.1),
\[
\delta(u)=H_f(u)-F(u)
 =\psi_f(u)-\sum_B\psi^{(|B|)}_{f_B}(u_B-x_B\mathbf1),
\qquad |\delta(u)|\le C_nD.
\tag{8.3}
\]
As long as all groups remain in this region, the \(Q\)-chain is the product of the separate group \(Q\)-chains. Both terms defining \(\delta\) are harmonic, so \(\delta\) is harmonic there.

We claim the following finite-radius estimate:
\[
|\delta(u)-\delta(z)|\le C_nD R^{-1/8}
\quad\hbox{if }u\in S_n,\quad |u_i-x_B|\le2.
\tag{8.4}
\]
Run the product of group chains from \(u\), and stop upon leaving the box with radius \(3R\), or at time \(t=R^{1/4}\). Exit points remain in (8.1), by the jump bound of two. The bounded stopped harmonic identity therefore applies to \(\delta\).

Each group's initial span is at most four. By (6.2), the chance that some group has not coalesced by time \(t\) is at most \(C_nt^{-1/2}\). By (2.2), the chance that any group leaves the smaller box of radius \(R\) by time \(t\) is at most \(C_n(t+1)/R^2\). On the complementary event, at time \(t\) each group is a full stack with center in that smaller box.

Restricted to such full-stack states, \(\delta\) is bounded and harmonic for independent rate-one stack random walks. Apply (6.3), and telescope one coordinate at a time from the original centers to the random centers. All intermediate centers stay in the smaller box. The expected sum of the center displacements is at most \(C_n(1+\sqrt t)\), by (2.2). Hence the stopped harmonic identity and (8.3) give
\[
|\delta(u)-\delta(z)|
 \le C_nD\left[
 t^{-1/2}+\frac{t+1}{R^2}
 +R^{-1/2}(1+\sqrt t)\right].
\]
With \(t=R^{1/4}\), every term is bounded by a constant times \(R^{-1/8}\). This proves (8.4). The estimates remain valid for singleton groups, whose coalescence time is zero. Fixed lattice margins in the boxes are harmless for \(R\ge16\); for example one may stop at radius \(3R-2\).

We now apply (8.4) to \(B\). Starting from \(z\), the first independent step, the following \(I\)-evolution, a second independent step, and the next \(I\)-absorption use only sites within distance two of their original group center. In particular all boundary values of \(\delta\) read in the expression \(RURP\delta(z)\) differ from the constant \(\delta(z)\) by at most \(C_nDR^{-1/8}\). Applying \(P\), then \(R\), then \(U\), and finally \(R|_{S_n}\), using respectively the bounds \(1,4n,c_n,2n\), shows
\[
|BH_f(z)-BF(z)|\le C_nDR^{-1/8}.
\tag{8.5}
\]
This is a local use of the linear operator expression: \(\delta\) need only satisfy (8.3)--(8.4) on the finite sets read by those operations.

Pure-\(I\) absorption factorizes over the separated groups. Thus \(PF\) locally is the sum of their absorption extensions. In a first-step \(I\)-excursion, only the initiating group can be outside its \(S\)-set; all other groups are full stacks. The contribution of another group to \(RPF\) is \(QH_{f_B}=0\). Therefore
\[
BF(z)=\sum_B
 B^{(|B|)}H^{(|B|)}_{f_B}(\mathbf0).
\tag{8.6}
\]
Apply the exact identity (7.7) group by group, with zero for singleton groups. Equation (8.2) identifies their directional derivatives with the required derivatives of \(f\) at \(z\). Combining (8.5)--(8.6) proves exactly
\[
\left|BH_f(z)-
 \sum_B\sum_{\varnothing\ne A\subsetneq B}
 \kappa_{A,B}\partial_{v_{A,B}}f(z)\right|
 \le C_nD R_*^{-1/8}.
\]
For one full block, (7.7) gives equality with no separation parameter. This proves item 3.

## 9. Separated covariance

For \(f_i(x)=x_i\), the bounded function \(\psi_{f_i}\), restricted to full-group configurations with centers within radius \(3R_*\) of the separated centers, is harmonic for independent rate-one stack random walks: \(Qf_i=0\) there and \(Q\psi_{f_i}=0\). The gradient estimate (6.3) gives
\[
|\psi_{f_i}(z+\epsilon\mathbf1_B)-\psi_{f_i}(z)|
 \le C_nR_*^{-1/2}.
\]
At the separated configuration, the exact \(Q\)-transitions are the whole-group translations \(z\mapsto z+\epsilon\mathbf1_B\), each at rate one. Consequently their corrected-coordinate increments are
\[
H_i(z+\epsilon\mathbf1_B)-H_i(z)
 =\epsilon\mathbf1_{\{i\in B\}}+O_n(R_*^{-1/2}),
\]
uniformly in every indicated choice. Multiplying these increments and summing the at most \(2n\) transitions proves
\[
|\Gamma_0^{ij}(z)-2\mathbf1_{\{z_i=z_j\}}|
 \le C_nR_*^{-1/2}.
\]
Equation (5.1) then proves
\[
|\Gamma_d^{ij}(z)-2\mathbf1_{\{z_i=z_j\}}|
 \le C_n(R_*^{-1/2}+d).
\]
This completes item 4.

## 10. One-label convention and quantifier check

For \(n=1\), use exactly the convention in the contract:
\[
S_1=\mathbb Z,\quad I=0,\quad
P=P_d=\operatorname{Id},\quad U=U_d=0,\quad
Q=T_d=R,\quad B=0,\quad d_1=1.
\]
A chamber-affine function on \(\mathbb R\) is affine, so \(Rf=0\), \(\psi_f=0\), and \(H_f=f\). The near set and every split sum are empty. Excursions start already in \(S_1\), hence \(\tau_d=J=0\), and the initiating displacement is one. The two unit-rate jumps give
\[
\Gamma_d^{11}=1+1=2.
\]
All potential and expansion identities are exact. For an affine function of Lipschitz constant \(D\), its trace \(p\)-moment rate is at most \(2D^p\). The coordinate random walk is a martingale with quadratic-variation rate two, so its expected squared maximal displacement up to time \(t\) is at most \(8t\). These verify every assertion under the one-label convention.

The proof fixed arbitrary \(n\), arbitrary allowed \(f,D\), arbitrary partitions, positions, oriented label subsets, \(p\ge1\), \(t\ge0\), and \(0<d\le d_n\). None of its constants depended on the spatial positions, their separations except through the displayed powers, the particular partition, or the function except through \(D\). There are finitely many occurrences of \(C_n\), so their maximum, enlarged to at least one, meets the simultaneous quantifier in the contract; the same holds for each fixed real \(p\) and \(C_{n,p}\). Constants and the case \(D=0\) are covered because a globally zero Lipschitz constant makes \(f\) constant and all its increments zero.

This is the complete independent argument offered for comparison. Every new mathematical conclusion remains at self-audited status. No conclusion about the unseen candidate or the campaign target is inferred.

