# C0005 promotion decision — v1

Status: promoted.

This decision applies exclusively to CANDIDATES/C0005_harmonic_correctors/CONTRACT_v2.md and PROOF_v2.md, with accepted BRIEF_v2.md, at the exact hashes below. Root read the complete reconstruction, its input manifest, every passing verification record, and rechecked the current hashes. Frozen creation-time candidate labels are preserved; this immutable later record states the earned status.

## Exact claim boundary

All six conclusions of the exact contract, with every definition, constant, quantifier, and the separate one-label convention, are promoted. These concern the labelled line-lattice chains and their canonical chamber-affine harmonic corrections:

1. Uniform pure-interaction absorption, the actual leading trace, near-set occupation and displacement.
2. The absolutely integrable canonical potential, its harmonicity, equivariance, full-stack and symmetric affine identities, and bounded residuals.
3. The exact full-stack coefficient for every oriented subset and the separated-block \(R_*^{-1/8}\) localization estimate.
4. The absolute and uniform covariance bounds, \(O(d)\) perturbation, and separated \(R_*^{-1/2}\) estimate.
5. The actual perturbed absorption/trace construction, ordered killed-resolvent identities, exact expansion and bounded remainder.
6. The inclusive-terminal independent-event count, its geometric and weighted moment bounds, displacement, arbitrary-start duration moments and rate-weighted trace jump moments for every real \(p\ge1\).

The contract fixes \(\kappa_{A,B}=(|A|-1)!(|B\setminus A|-1)!/(|B|-1)!\), all stated constants and parameter ranges. Its full text, rather than this inventory, is the dependency statement. No promoted campaign dependencies are used. No circle convergence, limiting martingale problem, or mass-process convergence is part of this auxiliary claim.

## Exact version and cadence inventory

| File | SHA256 |
|---|---|
| CANDIDATES/C0005_harmonic_correctors/CONTRACT_v2.md | 0a0130d01e482dbe546a19248b1ca67180aa373643dace7a87abc5cff8eb8cec |
| CANDIDATES/C0005_harmonic_correctors/PROOF_v2.md | 68a9fec530428b3fd61e9f3bef1564e3ad3bcbd905d0cf0b51801a58bd6fc5ef |
| CANDIDATES/C0005_harmonic_correctors/BRIEF_v2.md | 35a10be2298890820aeeb7ab72d47e3a0602f9ea7907cbd20666648353ed4e5b |
| CANDIDATES/C0005_harmonic_correctors/AUTHOR_INPUTS_v2.md | 5920bb21d0520d0e0407b58140b31c193c866138e8da9a90e665306f4a2014af |
| AUDITS/C0005_LEAKAGE_v2.md | 6875133397a178e7e85e1bbe617a682890cc41f280cf87e2cc615f949512c4c8 |
| AUDITS/C0005_HOSTILE_v2.md | b701df307a789ccf60a0624343cf95645f43ae6cdc2bafb6af1a6993c2c87bf2 |
| AUDITS/C0005_RECONSTRUCTION_v2.md | 8defb3caadc36081286f874eb9ce8d1adade2368341317b0fea1b9ff1e956e95 |
| AUDITS/C0005_RECONSTRUCTION_INPUTS_v2.md | c6f5cb3231ea0ed7c3722af4e0d3c955bb96fb080b50bafd8abca7413c57f875 |
| AUDITS/C0005_COMPARISON_v2.md | 18f21627cb0b5d076fbb43187d3bb4abb6121618c3be2ef0b2918c1fa6a489d7 |
| AUDITS/CHECKLIST_AC005.md and current AUDIT_CHECKLIST.md | d328652a06ff5ef7fa9ae64a70011a3060b32e80cc23b0afbce4cf1fca97c170 |

Leakage passed for the exact contract embedding and sole definition-only hint. The fresh hostile audit passed all auxiliary conclusions, explicitly treating unrelated full-convergence obligations as outside scope. The proof-blind reconstruction supplies a complete argument for the same canonical objects and all conclusions. Fresh comparison passed its correctness, exact quantifiers, dependency list and mechanism match.

The comparator explicitly checks the two presentations of reversible trace symmetry and the strengthened internal span-coalescence estimate. These are proved implementations of the same factorial boundary and bounded harmonic localization stages. They neither assume a new dependency nor replace the required canonical correction. The exact finite operator and directional coefficient identities agree.

The hostile audit used AC-005. Its snapshot and the current checklist remain byte-identical at promotion, as rechecked by root. No supplemental checklist items are pending. The exact version has completed all required verification steps; it is promoted by its entry in PROVED.md revision P-004.

## Provenance, outside audit, and completion boundary

The documented pre-audit v1 overwrite remains preserved in VERSION_NOTE_v2 and the author manifest. No claim of uninterrupted v1 immutability is made. The canonical v2 tuple was frozen before any verification role read it, and every passing record binds that exact tuple. This promotion does not validate the earlier v1 versions.

All verification roles used fresh allowlisted contexts with complete manifests. No eligible different-family model or human referee is available. Outside-family audit has not run; the label is promoted, not independently audited.

An outside referee should first check separated-block localization and its surviving \(B\)-action, then labelled factorial boundary coefficients, then the unbounded-corrector perturbed expansion and inclusive-terminal covariance coupling.

This removes the canonical corrector construction as an unproved dependency for the remaining microscopic convergence argument. C0004 v1's unsuccessful cadence remains unchanged. A materially new full-theorem candidate may now cite C0005 and C0006 as promoted dependencies, but that complete candidate must pass its own entire cadence. STATEMENT-v1 remains unaltered and the campaign remains running.
