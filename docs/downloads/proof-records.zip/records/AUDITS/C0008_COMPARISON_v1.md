# C0008 exact comparison — v1

Date: 2026-09-05. Role: fresh COMPARATOR. This report was composed completely and first-written once at this new path. It assigns no promotion or campaign-completion status.

**Verdict: PASS for the comparison of C0008 CONTRACT_v1 / PROOF_v1 / BRIEF_v1 with C0008_RECONSTRUCTION_v2, relative to the three expressly promoted dependency contracts in Section 1.** This is a version-bound mathematical comparison, not an assertion that a favorable impression, a matching last formula, or this role alone completes the campaign. The reconstruction reaches the exact submitted claim using the same substantive mechanism. Its alternative derivations are identified and checked below; none requires replacing an unproved step by a new campaign premise. There is a redundant-citation scope difference concerning Le Jan–Lemaire, explicitly resolved in Section 6 without admitting it as an additional contract premise.

The present check found no substantive mathematical gap in the reconstructed argument relative to the specified premises, and no failed candidate step that the alternative derivations silently repair. The exact source of each use and the limits of the input-isolation check are recorded below. No assertion is made about the contents or outcomes of audits unavailable to this role.

## 1. Exact bindings and input verification

All ten assigned local inputs were hashed together before their contents were read. Every SHA-256 matched the assignment.

| Actual local input | Verified SHA-256 |
| --- | --- |
| STATEMENT.md | ca925b943f2dc5573b840512e12ebd5f38fbdb15df7a6b02c3dd72f7ac698a97 |
| CANDIDATES/C0008_full_mass_convergence/CONTRACT_v1.md | 56bde5e0c1f439c43bf600aa9f0783b4f7da9ba8c6648e05072373af92b040cd |
| CANDIDATES/C0008_full_mass_convergence/PROOF_v1.md | 8d97fd0abba1232e8befd553489dd88a5239dbbdb962a8472e7e050dc9408868 |
| CANDIDATES/C0008_full_mass_convergence/BRIEF_v1.md | ec0c06433d0303df9a8c0120373103beed8b0f53687011f2b4b5834bf5c139f4 |
| CANDIDATES/C0008_full_mass_convergence/AUTHOR_INPUTS_v1.md | b7eadc69c7421c8dad47d989c8943d0cdb5e4c78ed527338cf09c60c01c3b78c |
| AUDITS/C0008_RECONSTRUCTION_v2.md | 88e53846cc7f218de25bbf4a25bbae1d4fad1805960ee8fe3119027b96686608 |
| AUDITS/C0008_RECONSTRUCTION_INPUTS_v1.md | 8e699f27974fd020c7db5507584898f87dd84f536323ebab6b877030e3c00973 |
| CANDIDATES/C0002_resolvent_path_transfer/CONTRACT_v1.md | d42cb0e8db6e9667f77d45f7e4d54994179e48b206fb343af6e50eaf67057c6b |
| CANDIDATES/C0005_harmonic_correctors/CONTRACT_v2.md | 0a0130d01e482dbe546a19248b1ca67180aa373643dace7a87abc5cff8eb8cec |
| CANDIDATES/C0006_uniform_thin_layers/CONTRACT_v2.md | 805ea9a15da4e350f0af208075932c45473a8f499a89f77f050c6c916c4891b9 |

The last three, and only those three campaign auxiliary statements, are treated as promoted premises by express assignment. Their immutable creation headers are not interpreted as revoking that authorization. Neither their proofs nor their promotion records were read.

A text-only check confirmed that STATEMENT.md occurs verbatim inside the contract and that the contract occurs verbatim inside the brief. The brief adds only its proof-blind introductory declaration and delimiters. It supplies zero proof steps or strategy hints. Therefore there is no separate hinted mechanism that the reconstruction can satisfy merely by repeating a supplied intermediate formula: mechanism agreement must be assessed against the actual proof, as done here.

## 2. Claim, hypotheses, quantified objects, and required outputs

In this report, “A” means the exact author PROOF_v1 and “R” the exact RECONSTRUCTION_v2.

| Exact contract requirement | Author location | Reconstruction location and check |
| --- | --- | --- |
| Every sequence with \(N/L_N\to\rho\in(0,\infty)\), \(Nd_N\to\Theta\in(0,\infty)\), and \(\alpha=\Theta/\rho\) | Opening normalization; IV.4 | R (1) uses \(q=N^2\), \(q/L^2\to\rho^2\), \(qd/L\to\rho^2\alpha\), and \(qd^2/L\to0\). The last limit follows from the preceding bounded limit and \(d\to0\). No stronger rate assumption occurs. |
| Exact directed nearest-neighbor accelerated occupancy generator; eventually \(L_N\ge3\) | I.1–I.2; IV.2 | R (2), (34)–(36) use the C0006 operators, with both directions and the same \(q,d\) at every label count. Taking the occupancy quotient at count \(N\) gives rate \(N^2\eta_x(1+\eta_y/d)\), exactly the prescribed rate. Since \(L_N\to\infty\), finitely many small tori do not affect convergence. |
| Each auxiliary order \(n\) fixed but arbitrary; no physical-tag autonomy | Opening; II; IV.2 | R Sections 1, 3–6 use every fixed \(n\); the labelled chains are auxiliary. R proves an averaging intertwining, not an assertion about a selected tagged subsystem. |
| Every fixed stack bound \(k\), every deterministic allowed initial sequence, isolated sites only at lattice scale | IV.4 | R (39) is uniform over all \(\Omega_N\); C0002 is then applied to every deterministic sequence with \(\Phi_N(\eta_N^0)\to\mu_0\). This includes every contract sequence for every fixed \(k\). The stronger all-state intermediate assertion does not alter the submitted claim. |
| Vanishing normalized stack masses, merging limiting locations, deterministic singular starts allowed | II.5; IV.4 | R initial absorption estimate, (31)–(32), (37)–(40) are uniform in initial positions and occupancies. No mass, macroscopic separation, stationarity, or absolute-continuity restriction enters. |
| \(\mathbb T=\mathbb R/\mathbb Z\), normalized Haar measure, exact partition weights and block-coordinate form | III.1–III.3 | R (8)–(12) use the same partition embeddings, factorial weights, block-coordinate derivatives, and coefficient \(\rho^2\). Boundary factors and all collision multiplicities are checked in Section 4 below. |
| Exact continuous-path target \(n\)-point semigroups, rather than pairwise stickiness alone | II.10–II.12; III | R (3)–(12), (26)–(31) identify the complete chamber-affine problem for arbitrary \(n\), including the full equality partition and all oriented splits. |
| Common-flow mass semigroup on every polynomial \(F_f\) | IV.2–IV.3 | R (36)–(38) and Section 7 use the exact identity \(\mathsf P_tF_f=F_{P_t^{(n)}f}\). No separate flows for different initial atoms are introduced. |
| Full untraced empirical-measure path law, all masses retained | I.3; II.5; IV.4 | R (20)–(22) remove the auxiliary trace time; R (33)–(40) transfer to the original occupancy process. The final projected process is exactly \(\Phi_N(\eta_N)\). |
| Tightness at stopping times and unique identification, not just finite-dimensional or equilibrium convergence | I.5; II–III; IV.4 | R (19), (23), Sections 4–5 give auxiliary path tightness/identification. R (39)–(40) verify every hypothesis of C0002; that exact promoted conclusion supplies mass stopping-time tightness and unique path-law identification. |
| Weak topology on \(\mathcal P(\mathbb T)\), \(J_1\) path topology, all finite horizons and \([0,\infty)\), continuous limit | II.12; IV.3–IV.4 | R (31), (39)–(41), with the compact-space Wasserstein metric, deliver exactly these objects and topologies. Horizons are arbitrary and increasing integer horizons give the usual local infinite-horizon path topology. |
| No Mosco proof and no substitution of an \(L^2\) or equilibrium limit | III versus I–II and IV | R Section 2 uses the already specified form only to identify its continuum generator. R Sections 3–7 are a martingale/occupation/path-law proof. |
| Verification cadence and any outside-family audit remain required before campaign completion | Contract final criteria; author status paragraphs | Neither mathematical argument confers those statuses. This report contributes only the requested comparison verdict and does not discharge unseen or later governance requirements. |

There is no refutation submitted, so the contract's alternative requirements for a fully specified counterexample do not apply.

## 3. Exact dependency applications and microscopic estimates

C0005 is a theorem on the line, with uniformity over positions, partitions, subsets, and a test's Lipschitz bound. Both arguments preserve this scope. R (14) applies it to
\[
f^{[L]}(z)=L f(z/L).
\]
This remains chamber-affine with the same Lipschitz constant \(D\); its directional derivatives satisfy
\[
\partial_v f^{[L]}(z)=\partial_v f(z/L).
\]
C0005(2),(5),(6) therefore give exactly R (15)–(18): correction error \(a_nD/L\), drift error bounded by \(C_nDqd^2/L\), corrected \(p\)-jump sums bounded by \(C_{n,p}D^pq/L^p\), and coordinate covariance \(q\Gamma_d^{ij}/L^2\). Additive constants cancel. These are uniform estimates, not an unjustified finite-separation identity.

The martingale estimates in R Section 3 are valid for its initially unbounded line functions. Stopping in finite boxes, bounded drifts and quadratic-jump sums give second-moment bounds. The correction comparison then bounds exit probabilities from growing boxes. Removing those stops establishes the martingales used in (19). For the fourth moments used in Section 5, expanding the fourth power of a compensated pure-jump martingale leaves the second-, third-, and fourth-jump terms. Their absolute compensators are bounded respectively by constants times its second moment, \(L^{-1}\) times its first absolute moment, and \(L^{-2}\), because \(q=O(L^2)\). This gives the stated finite-horizon fourth-moment bound. Thus products used in bracket identification are uniformly integrable; it is not enough merely to know separate coordinate tightness.

R (21) counts full excursion durations, including a possible terminal excursion and the initial absorption period. The physical duration is \(d/q\) times the C0005 duration, and independent initiating events have rate at most \(2nq\). This yields an \(O(d(T+q^{-1}))\) lost-time bound. R (22) uses the geometric excursion count tail and that rate bound to control the greatest displacement of all initiated excursions. Its separate arbitrary-start argument is valid: on the event of no independent jump, inclusion never enlarges the occupied support, and each initially connected line component has diameter at most \(n-1\). The exceptional probability is \(O(d)\), by the independent-event compensator and the uniform absorption mean. No arbitrary-start displacement hypothesis stronger than C0005 is assumed. The one-label convention removes every absorption and split term when \(n=1\).

C0006 is applied with the exact same \(q=N^2,d=d_N,L=L_N,n\), and \(k=\lfloor\varepsilon L\rfloor\), for fixed \(0<\varepsilon<1/4\) and sufficiently large \(N\). The two terms in its bound satisfy
\[
\frac{kT}{L+1/d}\le\frac{kT}{L},
\qquad
\frac{Lk}{q}=O(\varepsilon).
\]
Hence R (24) is uniform in all starting states. The conditional form covers bounded restarted intervals. R (25) transfers this estimate only while a line trace is in a chart with a larger coupling margin: except for vanishing clock/displacement failures, its retained-time integral is a subset of an original-circle integral on a bounded physical interval. The exceptional contribution is bounded by \(\binom n2T\). This is an actual occupation comparison and does not mistake trace time for physical time.

R (26) correctly addresses both mismatches of an equality indicator. A positive limiting distance eventually forbids discrete equality; when the limiting distance is zero, discrete inequality is contained in an arbitrarily thin positive layer under uniform path convergence. Taking \(N\to\infty\) and then \(\varepsilon\downarrow0\) proves convergence in expected time integral. Pair ordering then stabilizes at every time of distinct limiting coordinates, and finitely many pair indicators determine the weak-order cell. This proves (27). It neither removes positive time on equality strata nor assumes continuity of a collision indicator.

Off the positive layer, choose \(R_*\) so that \(16R_*\) is no larger than the least positive block separation. For each fixed \(\varepsilon\), \(R_*\) tends to infinity. C0005(3),(4), including the exact full-stack clause, give R (28)–(30). On the layer all drifts and covariances are bounded, so its expected duration controls the error. This verifies every use of the separated-block hypotheses and does not extend their asymptotic formula to arbitrary finite gaps.

## 4. Identification, localization, and the continuum normalization

The following is a mathematical check of the two arguments' all-strata identification, not reliance on a general statement that the targets “are compatible.”

For a partition refined by splitting \(B\) into \(A,C\), both proofs compute
\[
\frac{p_\alpha(\pi')}{p_\alpha(\pi)}
=\alpha\frac{(|A|-1)!(|C|-1)!}{(|B|-1)!}.
\]
Each side of the face \(u_A=u_C\) contributes once. Its unit-normal factor \(1/\sqrt2\) cancels the surface parameterization factor \(\sqrt2\). Therefore the physical splitting coefficient for each oriented subset is exactly
\[
\rho^2\alpha\frac{(|A|-1)!(|C|-1)!}{(|B|-1)!}.
\]
These coordinates are independent block coordinates in the displayed form; ambient block cardinalities do not change the normal factor. Multiple-boundary intersections have zero surface measure at that integration stage, while their own lower-dimensional stratum integrations remain in the form sum. Thus the calculation accounts for all partitions, not only two-point collisions.

Both arguments also justify that cutoff chamber-affine functions belong to the stated closed form domain. Along a stratum's tangent directions, every incident smooth piece has the same limiting derivative as its trace. Ambient mollification therefore converges in each tangential-gradient integral, with a uniform derivative bound; further coincidences have zero measure within that stratum. Finitely many dominated-convergence arguments give form-norm convergence. The bounded integration-by-parts density then places the cutoff function in the associated generator domain.

R derives all deterministic starts from the stationary generator identity by showing \(P_t(x,\cdot)\ll m_{\alpha,n}\) for every \(t>0\), using strong Fellerness, stationarity, and full support; it then lets the initial delay decrease to zero. A instead extends the semigroup identity itself from almost every point by continuity of both sides. Both derivations are valid: the generator density is bounded, so the disappearing initial integral is bounded by its norm times the delay. Neither leaves a quasi-everywhere exception. For coordinates and their products, the split derivatives cancel in opposite orientations, and
\[
L(x_ix_j)=2\rho^2\mathbf1_{\{x_i=x_j\}},
\]
which yields the required covariations.

The Howitt–Warren parameters in R (6)–(7) and A III.11–III.12 coincide. The positive entries are \(\alpha/2\) times the beta factorial ratio. Consistency on the axes follows from
\[
-\frac{\alpha}{2}H_{a-1}
=-\frac{\alpha}{2}H_a+\frac{\alpha}{2a};
\]
the origin is consistent as well. Positivity is required only when both indices are positive; the equal zero-index coefficients multiply opposite tangential derivatives and cancel. Dividing physical time rates by \(2\rho^2\) produces unit coordinate brackets. These checks match Definition 2.1, the consistency/positivity conditions, and Theorem 2.1 of [Howitt–Warren](https://arxiv.org/pdf/math/0611292v2). Its Proposition 8.1 supplies Borel continuation laws for the stopped-solution concatenation used in both arguments; the reconstruction's local uniqueness paragraph is an application of those named line laws, not a new circle uniqueness premise.

The localization is also substantive. A common cut in a uniformly empty arc gives nested chart margins. Within a chart, equality of lifts is exactly circle equality. Stopped line uniqueness follows by appending a line solution at the exit point and applying uniqueness to the concatenated martingale problem; bounded brackets and bounded chamber drifts justify localization and optional sampling. Conditional stopped laws then determine successive circle-chart segments. Every exit requires a fixed positive displacement, so uniform continuity forbids infinitely many exits on a finite horizon.

For limiting martingale identities, both proofs avoid an unsupported assumption about exit-time continuity. Truncated hitting times are monotone in a radius, so they have only countably many discontinuities pathwise. Fubini gives deterministic good radii for uniform-convergence passage. R's rational-start, nested-chart passage is consistent with A's more explicit rational-to-stopping-time construction: approximate an entry stopping time from above by dyadic times inside a smaller ball, stop additionally at its exit, and use the positive margin and bounded local integrals. These are the same local martingale identities, and conditional identities pass by bounded cylinder tests and a monotone class. There is no assumption that a subsequential limit is Markov before uniqueness is established.

The reference-form assertions used here match the partition recursion, equation (3.6), smooth core, and Theorem 3.3 of [Le Jan–Raimond](https://arxiv.org/pdf/math/0211387v1). Brownian one-point motion satisfies the paper's nonpolar-point condition. The displayed boundary computation, rather than the Howitt–Warren closing discussion about the Le Jan–Raimond family, identifies the exact target.

## 5. Differing derivations and mechanism comparison

The accepted brief contains the exact contract and no strategy hints. The substantive mechanism present in A is: uniform line correctors and their trace expansion; common-cut transfer and de-tracing; positive-layer replacement of all collision data; the complete chamber-affine martingale problem and target identification; exact sampling without replacement; polynomial density and uniform mass resolvents; C0002 path transfer. R implements each of these components. The following differences require more than noticing the same final formulas.

**Circle trace versus local original-path coupling.** A I.2–I.5 constructs the circle trace and proves rate-weighted comparison of its generators with line correctors. R Sections 3–5 works first with the line trace and then couples original line and circle chains up to a chart margin. It does not reproduce A's global circle-trace generator as an intermediate object. This is a different localization implementation of the same corrector/excursion mechanism, not an appeal to a new transfer theorem.

The critical rate-weighted step in A has been checked directly here; it is not certified solely because R reaches the same limit. If \(m=\lfloor h-n-2\rfloor\), a chart-crossing excursion needs at least \(m\) independent events. On the failure event both coupled marginal counts satisfy the geometric-tail bound. Circle corrected increments are \(O(DL)\); line increments are \(O(D(1+J))\). Consequently their expectation difference is \(O(DLr^m)\), because \(m=O(L)\). The analogous product bound is \(O(L^2r^m)\), and the \(p\)-moment bound is \(O(D^pL^pr^m)\). Summing the \(2n\) initiating attempts and then scaling gives precisely the errors \(O(qr^m)\) in A I.4.3–I.4.5. For fixed chart margin, \(m\) is proportional to \(L\), \(r\le1/4\), and \(q=O(L^2)\), so these errors vanish after acceleration. The stopped line/circle coupling used by R relies on the same rare-crossing estimate over \(O(qT)\) attempts. Thus no rate factor is lost in either implementation.

**Trace product integrability.** A II.4 uses bounded globally defined cut-lift functions on the finite circle and their product generator. R Section 5 uses unbounded line correctors stopped in a bounded chart and checks fourth moments of compensated martingales. Section 3 above verifies its compensator argument. Both give uniform integrability sufficient for the same bracket identity; R is not relying only on formal convergence of quadratic variations.

**Exact sampling identity.** A IV.2 proves a binomial-coefficient intertwining on occupancies by extracting a generating-function coefficient. R Section 6 proves it by an involution on ordered samples of distinct labels. Their sampling operators agree on symmetric tests: a tuple with occupation sample \(k\) has
\[
n!\prod_x\binom{\eta_x}{k_x}
\]
ordered distinct-label realizations, and \((N)_n=n!\binom Nn\). Hence R's \(J_{N,n}\) is exactly A's \(D_{N,n}\) after passing to occupancies. R's selected–unselected interaction contributions cancel with the sample in which the two labels are exchanged in the selected slot; symmetric graph rates agree and the test increments have opposite signs. Selected–selected terms give the \(n\)-label generator. This proves the same algebraic identity as A IV.2.4, including arbitrary functions after symmetrization. It does not assume autonomous physical tags. The repeated-index probability and resulting uniform \(n(n-1)\|f\|_\infty/N\) error agree.

**Fixed-time versus compact-time uniform semigroup convergence.** A IV.1 proves uniformity also in \(t\) on bounded intervals. R (32) proves only fixed-\(t\), all-start uniformity by compactness of starting positions and prescribed-start path convergence. For the exact C0002 hypothesis this is sufficient: the supremum of the fixed-time errors is bounded by \(2\|g\|_\infty\), and integrating it against \(e^{-\lambda t}\) gives the required uniform resolvent error by dominated convergence. R therefore proves every required output without claiming A's stronger intermediate compact-time estimate. No tightness conclusion is inferred from fixed-time convergence alone.

**Target mass continuity.** A IV.3 expands the fourth moment using the four-point polynomial semigroup and gives a dyadic continuity proof. R (13) uses the stipulated random-kernel representation and Jensen, followed by the usual moment continuity criterion. Its inequality can be checked at each deterministic measure \(\mu\) before taking any conditional expectation:
\[
\left|\int (K\varphi(x)-\varphi(x))\,\mu(dx)\right|^4
\le \int\!\int |\varphi(y)-\varphi(x)|^4K(x,dy)\,\mu(dx).
\]
Taking expectation uses only the one-point Brownian marginal and gives \(12\rho^4\operatorname{Lip}(\varphi)^4t^2\), uniformly in deterministic \(\mu\). The Markov property then evaluates this deterministic transition bound at \(\mu_s\). It does not substitute a random atom into a pointwise almost-sure identity with an uncontrolled exceptional set. A countable dense test family and compactness give a continuous mass version. Thus this alternative supplies exactly the continuous-realization hypothesis of C0002.

No known failing step has been bypassed. No hostile report or author's response to one was available to this role, so this statement is a finding of the checks just displayed, not a representation about unseen disputes. The changed intermediate derivations do not require a new candidate: they keep the exact claim, the same promoted premises, and the same corrector/occupation/martingale/sampling mechanism. A different claim or a new essential continuum or microscopic premise would require a separate candidate; none is granted here.

## 6. Literature-scope difference and its resolution

The reconstruction explicitly cites [Le Jan–Lemaire, Propositions 6–7](https://arxiv.org/pdf/math/0307106) in addition to LR/HW. Its source exposure is therefore broader than the author's, and its statement that all three papers are “ordinary continuum background” must not silently enlarge the exact contract's final LR/HW premise restriction.

I checked the actual uses instead of treating the papers as interchangeable. LL Proposition 6 repeats the Brownian partition-form construction, including the one-point generator \(\frac12\partial_{xx}\); Proposition 7 repeats the Feller mass-kernel construction. These are redundant here: the frozen contract already fixes the form, its time normalization, and the Feller mass semigroup with the kernel representation. R's own (9)–(12) computes the physical generator directly from that fixed form, and its mass continuity argument uses the representation already stipulated in the target. LR Section 3 also states that representation and Proposition 3.4(b) the induced Feller mass process. Thus no LL-only fact is needed to establish a new step or discharge an otherwise missing hypothesis.

For this exact PASS, LL receives **source-check exposure only, no additional mathematical-premise status**. This does not edit R, change the target, or fill a substantive missing lemma: all facts at issue are already fixed target properties or the same named LR construction. A literal editorial cleanup of the reconstruction's broader-background wording would be clearer, but is not necessary to make the mathematical premise graph identical. In particular, no LL Beta-flow approximation or convergence result is used.

## 7. Final mass transfer and the scope of the conclusion

Both proofs obtain the sampling error uniformly over every occupancy state. Compactness and Stone–Weierstrass extend polynomial convergence to every continuous mass test, because polynomials contain constants, separate measures, and are closed under products. Resolvent integration gives R (39) for every \(\lambda>0\), every continuous \(g\), and the full supremum over \(\Omega_N\).

The exact C0002 dictionary is
\[
E=\mathcal P(\mathbb T),\qquad S_N=\Omega_N,\qquad
Z_N=\eta_N,\qquad \pi_N=\Phi_N,\qquad P_t=\mathsf P_t.
\]
The state space is compact metric in the weak topology, the chains are finite-state, the target is conservative strongly continuous Feller with a continuous realization, and a microscopic jump has projected Wasserstein distance at most
\[
\frac{1}{NL_N}\longrightarrow0.
\]
These check both exact C0002 hypotheses over all microscopic states. C0002 supplies the stopping-time tightness and unique identification required for the entire projected \(J_1\) law. The final conclusion is the contract's
\[
\operatorname{Law}_{\eta_N^0}(\mu_N(\cdot))
\Longrightarrow Q_{\mu_0}
\quad\text{in }D([0,\infty),\mathcal P(\mathbb T)).
\]
The full dense polynomial family fixes the common-flow target; no limitation to one-time moments, finite physical tags, or equilibrium survives the final transfer.

## 8. Isolation audit of the two actual-input manifests

The author manifest declares an author-assembly role, not an independent reconstruction. It lists the statement, the three exact promoted contracts, authorized trace/target author modules and their provenance records, and the permitted tail of an earlier author proof with its provenance record. It expressly denies opening the earlier proof sections, dependency proofs, audit material, registries, or another author's defense. Those prior author sources are not hidden: their arguments are present in A, and only the three promoted contracts have auxiliary-premise status. The manifest lists two directly consulted primary sources and administrative incoming promotion hashes. Nothing in the permitted files contradicts that declared author boundary. The provenance paths merely named there were not followed by this comparator.

The reconstruction manifest lists exactly the statement, contract, accepted brief, and three promoted contracts as local mathematical inputs. Its direct literature query seeks the named Howitt–Warren continuum theorem; it is not a search for the SIP target's solution or open status. The incidental result titles are recorded as exposure and denied premise status. It reports no author proof, author manifest, existing audit, dependency proof, registry, route argument, or other reconstruction read, no mathematical advice, no subagent, and no mathematical program. Its first-write status request and subsequent literal-delimiter feedback are administrative. Its v1-to-v2 repair is reported to change rendering only. The comparator was expressly prohibited from reading v1, so this report verifies the assigned v2 hash and the manifest's declaration, and does not claim a forensic comparison of v1/v2 bytes.

Accordingly the required isolation is **satisfied on the complete declared input records available to this role**. This is not an independent attestation of unseen tool logs. The author is not credited as proof-blind; the reconstructor is not credited with reading only sources common to the author, since its broader ordinary-source exposure is disclosed. Neither manifest supplies an undisclosed mathematical premise to this comparison.

## 9. Comparator's complete actual-exposure and operation manifest

The complete pre-existing local input list is exactly Section 1. A first parallel display exceeded the aggregate output budget; the five C0008 author/reconstruction texts and both actual-input manifests were then displayed in individual or bounded-range reads until the complete assigned arguments and manifests had been seen. The three dependency contracts and statement/contract were fully displayed. Local operations were limited to hashing, exact-file reading, line counts, text inclusion checks, the new-output existence check, and writing/inspecting this output. An existence check returned that this report path did not yet exist. No filesystem discovery search was performed.

The only direct external sources opened by this comparator were:

| Primary source actually opened | Exposure and permitted use |
| --- | --- |
| https://arxiv.org/pdf/math/0211387v1 | Initial PDF extraction exposed Sections 1–3 through the start of Theorem 3.3's proof; a find for Proposition 3.4 and an open at extraction line 584 exposed the remaining construction and Proposition 3.4 with surrounding text. Checked the target partition recursion, form/core, compatibility, strong Fellerness, and mass-kernel statement. |
| https://arxiv.org/pdf/math/0611292v2 | Initial PDF extraction; finds for Theorem 2.1 and Proposition 8.1; opens at extraction lines 174 and 370. Exposed the definitions, orientation, consistency and positivity, uniqueness, Feller proposition, and neighboring snippets including later lattice/flow statements. Only the named continuum martingale problem and Feller continuation laws were used. |
| https://arxiv.org/pdf/math/0307106 | Initial PDF extraction; finds for Propositions 6 and 7; open at extraction line 882. Exposed Section 3.2, the Brownian convention, Propositions 6–7, and the adjacent beginning of the Beta-flow convergence section. Used only to check R's citations and their redundancy under Section 6; no Beta-flow convergence premise was admitted. |

There was no external search query by this comparator, no target-solution or openness search, no external source beyond those three direct primary PDFs, no local download or literature file read, and no visual PDF rendering. Consequently there are no comparator-owned local literature hashes. The exact URLs above bind its direct source exposure. Bibliographic names and incidental approximation statements displayed by the web extraction were not followed or used.

The inherited context consisted of the exact comparator assignment, the user-supplied rigor/renderer-safe-LaTeX instructions, and generic workspace/tool context. The assignment supplied no hostile objections, leakage report, checklist, dependency proof, prior reconstruction argument, or author's defense. Outbound root progress messages described this comparator's own hash check and derivation comparison; they requested no mathematical advice. No subagent was spawned, and no mathematical program, symbolic calculation, numerical experiment, simulation, or theorem prover was used. The only Python operation before this write checked literal text containment. No path named merely inside an allowed manifest was opened.

Any subsequent balance/hash checks of this report and delivery of its digest are administrative checks of the comparator's own newly written output. This report does not modify any input, author version, reconstruction version, dependency, registry, or mathematical status.

